# Keyboard Events

This library currently provides very basic support for keyboard events.

Longer-term, it makes sense to help track key combinations and a couple other
common scenarios. If you have a particular problem you think this library could
address more directly, please describe it as a [SSCCE](http://sscce.org/) in an
issue. Please do not suggest the solution. Just describe the scenario. Once it
becomes clearer what folks are up to, it will be time to add support for those
cases in a coherent way.