module Repl exposing (..)
d_e_l_t_r_o_n_3_0_3_0 =
  exit
t_s_o_l = ()
