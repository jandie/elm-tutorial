const myAPI = {
  greet(name) {
    console.log(`Greetings, ${name}`);
  },
  sayBye() {
    console.log('Goodbye');
  },
};

export default myAPI;
